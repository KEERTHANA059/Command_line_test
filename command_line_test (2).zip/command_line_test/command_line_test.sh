<<doc
        Name            : R KEERTHANA
        Date            : 31-12-2022
        Description     : WAP to create a login page
        Sample input    : 1. Signup
                          2. Signin
                          3. Exit 
                          Enter the choice : 
        Sample output   : 2
                          Enter the username: Emertxe
                          Enter the password: 123qwe
                          Signin successful
doc

#-----------------------------------------------------------------------------------------------

#!/bin/bash
function signup()                                         # function to signup 
{   
    flag=0                                                # initialize flag to 0
    read -p "Enter the username : " username              # Enter the username
    for i in `seq 0 $len`                                 # loop runs for all values until len
    do
        if [ $username = ${user[$i]} ]                    # if username entered is equal to usernames in csv file
        then
            flag=1                                        # then update flag to 1
        fi
    done
    if [ $flag = 0 ]                                      # if flag is 0, given username is not in csv file 
    then
        read -sp "Enter the password" password            # read password from user
        echo
        read -sp "Comfirm the password" repassword        # confirm the password
        if [ $password = $repassword ]                    # if password is equal to repassword
        then
            echo $username >> username.csv                    # append username into csv file
            echo $password >> password.csv                # append password into csv file
            echo -e "\nSignup successful\n"               # print signin successful
            exam                                          # jump to function exam to take test
        else
            echo "Enter the correct password"             # if user password and repassword are not same then print error
            signup                                        # jump to function signup
        fi
    else    
        echo "Username already exist"                     # if username already exist print error
        signin                                            # jump to function signin
    fi
}
function signin()                                         # funcion to signin
{
    flag=0                                                # initialize flag to 0
    read -p "Enter the username : " username              # Enter the username
    for i in `seq 0 $len`                                 # loop runs until value to len
    do
        if [ $username = ${user[$i]} ]                    # if given username already exist 
        then
            read -sp "Enter the password" password        # read the password
            echo
            index=$i                                      # store the username in csv file index value in index variable
            flag=1                                        # update flag to 0
            break                                         # break the loop
        fi
    done
    if [ $flag -eq 1 ]                                    # if flag is 1
    then
        if [ $password = ${pass[$index]} ]                # check the password is equal to the index value in password csv file
        then
            echo -e "Signin successful\n"                 # print signin successful
            exam                                          # jump to exam to take test
        else
            echo "Enter the correct password"                 # if password and csv file password are not same
            signin                                        # jump to signin            
        fi
    else
        echo "Username doesn't exist"                     # prints username doesn't exist
        signup                                            # jump to signup function
    fi
}
function exam()                                           # function to exam
{
    count=0                                               # initialize count value to zero
    echo -e "1.Take the test\n2.Exit"                     # print options for taking exam
    read -s take_test                                     # read option from user 
    case $take_test in                                    # for the option given by user 
        1)  echo "Test started"                           #  if i is given take test
            for i in `seq 5 5 50`                         # loop runs for ever 5 numbers until 50
            do
                head -$i questionbank.txt | tail -5       # prints the 5 lines in question bank
                for i in `seq 5 -1 1`                    # loop gives 30 to 1 in decreasing order
                do
                    echo -ne "\rEnter the option :$i "    # prints the echo in same line
                    read -t 1 option                      # read option with time delay 1sec
                    if [ -n "$option" ]                   # if option is given
                    then
                        
                        echo $option >> user_answer.csv       # store it in useranswer file
                        break
                    fi
                done
                if [ -z $option ]
                then
                        option="e"                        # if no input  given store e in option
                    echo $option >> user_answer.csv
                fi
                echo Option is $option                    # print the user given option
            done
            echo
            answer=(`cat answerbank.csv`)                 # take all answer bank in array
            input=(`cat user_answer.csv`)                 # take all user answers in array
            lines=$((${#answer[@]}-1))                    # assign the length of answer to len
            for i in `seq 0 $lines`                       # for all values from 1 to len
            do
                if [ ${answer[$i]} = ${input[$i]} ]       # if user input and answer both are equal
                then 
                    count=$(($count+1))                   # increase the count
                fi
            done
            echo -e "\e[1;32mNumber of correct answers :$count/${#answer[@]}\e[0m "  # print the correct answers count
            exit ;;
        2)exit ;;                                         # if 2 is given exit from the loop
        *)echo "Choose the given option" ;;               # apart from 1 and 2 for all option print error 
    esac                    
}
var="0"                                                   # initialize var to 0
while [ $var != "3" ]                                     # loop continues until var is 3
do
    sed -i '1,$d' user_answer.csv                         # clear user_answer file before loading the user answers
    user=(`cat username.csv`)                                 # take user.csv file in array
    pass=(`cat password.csv`)                             # take password.csv in array
    len=$((${#user[@]}-1))                                # find length of array user    
    echo -e "\t \e[1;33m  Welcome to the test\e[0m"       # to display welcome statement
    echo -e "\e[1;37m1-Signup\n2-Signin\n3-Exit\e[0m"     # display options
    read -p "Enter the choice : " num                     # read user input
    case $num in                                          # for user given options for below
        1) signup ;;                                      # if 1 is given jump to signup function
        2) signin ;;                                      # if 2 is given jump to signin function
        3) exit   ;;                                      # if 3 is given exit from the program
        *) echo "not valid" ;;                            # for all other options print error
    esac                                                  # close the case statement
done
